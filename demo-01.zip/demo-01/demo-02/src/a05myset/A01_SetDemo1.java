package a05myset;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class A01_SetDemo1 {
    //这些方法的顶层都是collection
    public static void main(String[] args) {
        /*
        利用set系列的集合,添加字符串,并使用多种方式遍历
         */

        //1.创建一个Set集合的对象
        Set<String> s = new HashSet<>();

        //2.添加元素
        //如果当前元素是第一次添加,那么可以添加成功,返回true
        boolean r1 = s.add("aaa");
        boolean r2 = s.add("aaa");
        boolean r3 = s.add("bbb");

        System.out.println(r1);
        System.out.println(r2);
        System.out.println(s);
        //3.打印集合
        //无序

        //遍历器遍历
//        Iterator<String> it = s.iterator();
//        while (it.hasNext()){
//            String str = it.next();
//            System.out.println(str);
//        }

        //增强for
//        for (String str : s){
//            System.out.println(str);
//        }
        s.forEach(str-> System.out.println(str));
    }
}
