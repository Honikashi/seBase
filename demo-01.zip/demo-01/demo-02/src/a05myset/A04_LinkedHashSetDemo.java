package a05myset;

import java.util.LinkedHashSet;

public class A04_LinkedHashSetDemo {
    public static void main(String[] args) {
        //1.创建4个学生对象
        Student3 s1 = new Student3("zhangsan",23);
        Student3 s2 = new Student3("lisi",24);
        Student3 s3 = new Student3("wangwu",25);
        Student3 s4 = new Student3("zhangsan",23);

        //2.创建集合的对象
        LinkedHashSet<Student3> lhs = new LinkedHashSet<>();

        //3.添加元素
        System.out.println(lhs.add(s1));
        System.out.println(lhs.add(s2));
        System.out.println(lhs.add(s3));
        System.out.println(lhs.add(s4));

        //4.打印集合
        System.out.println(lhs);
    }
}
