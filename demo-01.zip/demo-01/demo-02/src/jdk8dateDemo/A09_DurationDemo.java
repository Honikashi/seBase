package jdk8dateDemo;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class A09_DurationDemo {
    public static void main(String[] args) {
        //本地日期时间对象
        LocalDateTime today = LocalDateTime.now();
        System.out.println(today);

        //出生的日期时间对象
        LocalDateTime birthDate = LocalDateTime.of(2000, 1,1
        ,1,0,00);
        System.out.println(birthDate);
        Duration duration = Duration.between(birthDate, today);//第二个参数减第一个参数


        System.out.println(duration.toDays());
        System.out.println(duration.toHours());
    }
}
