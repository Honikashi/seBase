package jdk8dateDemo;

import java.time.ZoneId;
import java.util.Set;

public class A01_ZoneIdDemo1 {
    public static void main(String[] args) {
            /*
    static set<string>getAvailablezoneIds()     获取Java中支持的所有时区
    static zoneId systemDefault()               获取系统默认时区
    static zoneId of(string zoneId)             获取一个指定时区
     */

        //1.获取所有的时区名称
        Set<String> zoneIds = ZoneId.getAvailableZoneIds();
        System.out.println(zoneIds.size());
        System.out.println(zoneIds);

        //2.获取当前系统的默认时区
        ZoneId zoneId = ZoneId.systemDefault();
        System.out.println(zoneId);

        //3.获取指定的时区
        ZoneId zoneId1 = ZoneId.of("America/Cuiaba");
        System.out.println(zoneId1);

    }

}
