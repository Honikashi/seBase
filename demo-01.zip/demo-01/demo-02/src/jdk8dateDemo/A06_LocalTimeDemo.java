package jdk8dateDemo;

import java.time.LocalDate;
import java.time.LocalTime;

public class A06_LocalTimeDemo {
    public static void main(String[] args) {
        //获取本地时间的日历对象,(包含 时 分 秒)
        LocalTime nowTime = LocalTime.now();
        System.out.println("今天的时间"+nowTime);

        int hour = nowTime.getHour();
        System.out.println(hour);

        //指定时间可以在 时 分 秒 纳秒
        System.out.println(LocalTime.of(8, 20));
        System.out.println(LocalTime.of(8, 20, 30, 50));
        LocalTime mTime = LocalTime.of(8, 20, 30, 50);
        //is系列的方法
        System.out.println(nowTime.isBefore(mTime));
        System.out.println(nowTime.isAfter(mTime));

        //with系列的方法,只能修改时,分,秒
        System.out.println(nowTime.withHour(10));
        System.out.println(nowTime.minusHours(10));
        System.out.println(nowTime.plusHours(10));


    }
}
