package jdk8dateDemo;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class A02_ZoneIdDemo2 {
    public static void main(String[] args) {
        /*
            static Instant now()                        获取当前时间的Instant对象(标准时间)
            static Instant ofxxxx(long epochMilli)      根据(秒/亳秒/纳秒)获取Instant对象
            ZonedDateTime atZone(ZoneId zone)           指定时区
            boolean isXxx(Instant otherInstant)         判断系列的方法
            Instant minusXxx(long millisTosubtract)     减少时间系列的方法
            Instant plusXxx(long millisTosubtract)      增加时间系列的方法
        */
        //1.获取当前时间的Instant的对象(标准时间)
//        Instant now = Instant.now();
//        System.out.println(now);

        //2.根据(秒/亳秒/纳秒)获取Instant对象
        Instant instant1 = Instant.ofEpochMilli(0L);
        System.out.println(instant1);//1970-01-01T00:00:00Z

        Instant instant2 = Instant.ofEpochSecond(1L);
        System.out.println(instant2);//1970-01-01T00:00:01Z

        Instant instant3 = Instant.ofEpochSecond(1L, 100000000000000L);
        System.out.println(instant3);

        //3.指定时区
        ZonedDateTime time = Instant.now().atZone(ZoneId.of(ZoneId.systemDefault().toString()));
        System.out.println(time);

        //4.isXxx 判断
        Instant instant4 = Instant.ofEpochMilli(0L);
        Instant instant5 = Instant.ofEpochMilli(1000L);

        boolean before = instant4.isBefore(instant5);
        System.out.println(before);//true

        boolean after = instant4.isAfter(instant5);
        System.out.println(after);//false

        //6.Instant minusXxx(long millisTosubtract)     减少时间系列的方法
        Instant instant6 = Instant.ofEpochMilli(28282848L);

        Instant instant7 = instant6.minusSeconds(1);
        System.out.println(instant7);


    }
}
