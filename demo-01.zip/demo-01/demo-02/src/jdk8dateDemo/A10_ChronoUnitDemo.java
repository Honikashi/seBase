package jdk8dateDemo;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class A10_ChronoUnitDemo {
    public static void main(String[] args) {
        //当前时间
        LocalDateTime today = LocalDateTime.now();
        System.out.println(today);

        LocalDateTime birthDate = LocalDateTime.of(2005, 3, 25,
                0, 0, 0);
        System.out.println(birthDate);

        System.out.println("相差的年数"+ChronoUnit.YEARS.between(birthDate, today));
    }
}
