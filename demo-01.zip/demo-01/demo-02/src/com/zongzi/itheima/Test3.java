package com.zongzi.itheima;

public class Test3 {
    public static void main(String[] args) {
        /*
          有一堆桃子，猴子第一天吃了其中的一半，并多吃了一个!
          以后每天猴子都吃当前剩下来的一半，然后再多吃一个,
          第10天的时候(还没吃)，发现只剩下一个桃子了，请问，最初总共多少个桃子?
         */
        System.out.println(getCount(1));
    }

    public static int getCount(int days) {
        if (days <= 0||days>=11){
            System.out.println("当前时间错误");
            return -1;
        }
        //递归的出口
        if (days == 10){
            return 1;
        }
        return  (getCount(days + 1) +1)*2;
    }
}
