package com.zongzi.itheima;

import java.util.ArrayList;

public class TestAnimal {
    public static void main(String[] args) {
        ArrayList<LiHuaCat> list1 = new ArrayList<>();
        ArrayList<PersianCat> list2 = new ArrayList<>();
        ArrayList<HuskyDog> list3 = new ArrayList<>();
        ArrayList<TaddyDog> list4 = new ArrayList<>();
        keepPet(list1);
        keepPet(list2);
        keepPet(list3);
        keepPet(list4);
    }
    public static void keepPet(ArrayList<? extends Animal> list) {

    }


    //要求二只能养狗
//    public static void keepPet(ArrayList<? extends Dog> list) {
//
//    }
    //要求1:该方法能养所有品种的猫,但是不能养狗
//    public static void keepPet(ArrayList<? extends Cat> list) {
//
//    }
}
