package com.zongzi.itheima;

public abstract class Dog extends Animal{
}
