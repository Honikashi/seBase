package com.zongzi.itheima;

public class Test4 {
    public static void main(String[] args) {
        System.out.println(getMethod(20));
    }
    public static int getMethod(int steps){
        if (steps == 1){
            return 1;
        }
        if (steps == 2){
            return 2;
        }
        if (steps == 3){
            return 4;
        }
        return getMethod(steps - 1) + getMethod(steps -2) + getMethod(steps -3);
    }
}
