package com.zongzi;


import java.util.Random;

public class strongfor {
    public static void main(String[] args) {
        float[] values = new float[5];
        Random random = new Random();
        for (int i = 0; i < 5 ; i++){

            values[i] = random.nextFloat();
        }
//        String strvalue = floatArrayToString(values);
//        System.out.println(strvalue);
        for (float value : values){
            System.out.println(value);
        }

    }
    private static String floatArrayToString(float[] array){
        StringBuilder sb = new StringBuilder();
        for (float value : array){
            sb.append(value).append(",");
            System.out.println(sb);
        }
        return sb.toString();
    }
}
