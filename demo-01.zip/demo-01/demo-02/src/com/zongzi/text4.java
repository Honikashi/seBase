package com.zongzi;

public class text4 {
    public static void main(String[] args) {
        int[][] yearArrArr = {
                {20, 21, 23},
                {25, 216, 235},
                {201, 214, 235},
                {209, 251, 213}
        };
        int yearSum = 0;
        for (int i = 0; i < yearArrArr.length; i++) {
            //i二维数组中的每一个索引
            //yearArrArr[i]元素(一维数组)
            int quartArr = getsum(yearArrArr[i]);
            System.out.println("第"+(i+1)+"季度"+quartArr);
            yearSum = yearSum +quartArr;
        }
        System.out.println(yearSum);
    }

    public static int getsum(int[] arr){
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum = sum+arr[i];
        }return sum;
    }

}
