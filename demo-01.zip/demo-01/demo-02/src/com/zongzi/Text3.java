package com.zongzi;

import java.util.Random;
import java.util.Scanner;

public class Text3 {
    public static void main(String[] args) {

        int[] arr = creatNumber();
        System.out.println("=======================");

        for (int k = 0; k <arr.length; k++) {
            System.out.println(arr[k] +" ");
        }
        System.out.println("=======================");
        int[] userInputArr = userInput();
        int redcount = 0;
        int bulecount = 0;
        for (int i = 0; i < userInputArr.length-1; i++) {
            int redNumber = userInputArr[i] ;
            for (int j = 0; j < arr.length-1; j++) {
                if(redNumber==arr[j]){
                    redcount++;
                    break;
                }
            }
        }
        int buleNumber = userInputArr[userInputArr.length-1];
        if(buleNumber==arr[arr.length-1]){
            bulecount++;
        }

        System.out.println("红球中将的个数"+redcount);
        System.out.println("蓝球中将的个数"+bulecount);
    }

    public static int[] userInput() {
        int[] arr = new int[7];
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 6; ) {
            System.out.print("请输入第" + (i + 1) + "个号码");
            int redNumber = sc.nextInt();
            if (redNumber >= 1 && redNumber <= 33) {
                boolean flag = contain(arr, redNumber);
                if (!flag) {
                    arr[i] = redNumber;
                    i++;
                } else {
                    System.out.println("号码重复");
                }
            } else {
                System.out.println("当前号码超出红球范围");
            }
        }
        System.out.println("请输入蓝球范围");
        int buleNumber = sc.nextInt();
        while (true) {
            if (buleNumber >= 1 && buleNumber <= 16) {
                arr[6] = buleNumber;
                break;
            } else {
                System.out.println("您输入的蓝球号码超出范围");
            }
        }

        return arr;
    }

    public static boolean contain(int[] arr, int number) {
        for (int i = 0; i < 6; i++) {
            if (arr[i] == number) {
                return true;
            }
        }
        return false;
    }

    public static int[] creatNumber() {
        int[] arr = new int[7];
        Random r = new Random();
        for (int i = 0; i < arr.length - 1; ) {
            int redNumber = r.nextInt(33) + 1;
            boolean flag = contain(arr, redNumber);
            if (!flag) {
                arr[i] = redNumber;
                i++;
            }
        }

        int buleNumber = r.nextInt(16) + 1;
        arr[6] = buleNumber;
        return arr;
    }

}
