package com.zongzi;

import java.util.Scanner;

public class Text1 {
    public static void main(String[] args) {
        int[] scoreArr = getScore();
        for (int j = 0; j < 6; j++) {
            System.out.println(scoreArr[j]);

        }
    }

    public static int[] getScore() {
        int[] scores = new int[6];
        Scanner sc = new Scanner(System.in);
        for (int k = 0; k < 6; k++) {
            int score = sc.nextInt();
            scores[k] = score;
        }
        return scores;

    }
}
