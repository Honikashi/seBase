package com.zongzi;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class lianshou {
    public static void main(String[] args) throws ParseException {
        String str = "2023年09月10日";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");
        Date date = sdf.parse(str);
        long time = date.getTime();

        long end = time - 1000*60*60*24*30;

        String result = sdf.format(end);
        System.out.println(result);

    }

}