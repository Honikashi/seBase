package com.zongzi;


public class homework {
    public static void main(String[] args) {
        int[] arr = {27, 22, 30, 40, 36,
                13, 19, 16, 20,
                7, 10,
                43, 50, 48};

        Block1 b1 = new Block1(22, 40, 0, 4);
        Block1 b2 = new Block1(13, 20, 5, 8);
        Block1 b3 = new Block1(7, 10, 9, 10);
        Block1 b4 = new Block1(43, 50, 11, 13);
        Block1[] block1sArr = {b1, b2, b3, b4};
        int number = 40;
        int Index = getIndex(block1sArr, arr, number);
        System.out.println(Index);
    }

    private static int getIndex(Block1[] block1sArr, int[] arr, int number) {
        int indexBlocks = findIndexBlock1(block1sArr, number);
        if (indexBlocks == -1){
            return -1;
        }
        int startIndex = block1sArr[indexBlocks].getStartIndex();
        int endIndex = block1sArr[indexBlocks].getEndIndex();
        for (int i = startIndex; i < endIndex; i++) {
            if (arr[i] == number) {
                return i;
            }
        }
        return -1;
    }

    private static int findIndexBlock1(Block1[] block1sArr, int number) {
        for (int i = 0; i < block1sArr.length; i++) {
            if (block1sArr[i].getMin() <= number && number <= block1sArr[i].getMax()) {
                return i;
            }
        }

        return -1;
    }


}

class Block1 {
    private int min;
    private int max;
    private int startIndex;
    private int endIndex;

    public Block1(int min, int max, int startIndex, int endIndex) {
        this.min = min;
        this.max = max;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
    }

    public Block1() {
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public int getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }

    public int getEndIndex() {
        return endIndex;
    }

    public void setEndIndex(int endIndex) {
        this.endIndex = endIndex;
    }
}