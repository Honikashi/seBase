package com.zongzi;

import java.util.Random;

public class Text {
    public static void main(String[] args) {
        char[] csh = new char[52];
        for (int i = 0; i < csh.length; i++) {
            if (i <= 25) {
                csh[i] = (char) (97 + i);
            } else {
                csh[i] = (char) (65 + i - 26);
            }
        }
        Random r = new Random();
        String result = "";
        for (int k = 0; k < 4; k++) {

            int randomindex = r.nextInt(csh.length);
            //System.out.println(csh[randomindex]);
            result = result + csh[randomindex];
        }
        //System.out.println(result);
        int number = r.nextInt(10);
        result = result +number;
        System.out.println(result);
    }
}
