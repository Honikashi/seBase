package mysort;

public class A04_RecursionDemo1 {
    public static void main(String[] args) {
        method();
    }

    private static void method() {
        method();
    }
}
