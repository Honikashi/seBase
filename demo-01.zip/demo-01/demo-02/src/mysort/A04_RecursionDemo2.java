package mysort;

public class A04_RecursionDemo2 {
    public static void main(String[] args) {
        System.out.println(getFactorialRecursion(6));
    }
    public static double getFactorialRecursion(int number){
        if (number == 1){
            return 1;
        }
        //如果number不是1
        return number * getFactorialRecursion(number - 1);

    }
}
