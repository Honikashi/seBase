package mycollection;

import java.util.ArrayList;
import java.util.Collection;

public class A06_CollectionDemo6 {
    public static void main(String[] args) {
        Collection<String> coll = new ArrayList<>();
        coll.add("aaa");
        coll.add("bbb");
        coll.add("ddd");
        coll.add("ccc");

        //利用增强for进行遍历
        //注意点:
        //s其实就是一个第三方变量,在循环的过程中依次表示集合中的每一个数据
        for (String s : coll) {
            System.out.println(s);
        }
    }
}
