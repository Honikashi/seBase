package androidUse;




import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Service {
    public static void main(String[] args) throws IOException {

            ServerSocket server = new ServerSocket(500);
            Socket socket = server.accept();

        BufferedReader reader = new BufferedReader
                (new InputStreamReader(socket.getInputStream(),"UTF-8"));
        try{
            String receiveMsg = null;
            while (true){
                if ((receiveMsg = reader.readLine()) != null){
                    System.out.println("server"+receiveMsg);
                }
            }
        }catch (IOException e){
            System.out.println(e);
        }

    }
}
