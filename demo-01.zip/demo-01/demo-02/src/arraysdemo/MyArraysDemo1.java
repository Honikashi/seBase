package arraysdemo;

import java.util.Arrays;

public class MyArraysDemo1 {
    public static void main(String[] args) {
        //toString: 将数组变成字符串
        System.out.println("-------------toString--------------");
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        System.out.println(Arrays.toString(arr));

        //binarySearch二分查找法查找元素
        //如果查找得元素是不存在得,返回得是-插入点-1
        //为了避免输入的是0的情况
        System.out.println("------------binarySearch------------");
        System.out.println(Arrays.binarySearch(arr, 10));

        //copyOf:拷贝数组
        //参数1:老数组
        //参数2:新数组的长度
        //方法的底层会根据第二个参数来创建新的数组
        System.out.println("------------copyOfRange-------------");
        int[] newArr1 = Arrays.copyOf(arr, 20);
        System.out.println(Arrays.toString(newArr1));

        //copyOfRange:拷贝数组(指定范围)
        //细节:包头不包尾,包左不包右
        System.out.println("-----------copyOfRange-------------");
        int[] newArr2 = Arrays.copyOfRange(arr, 0, 9);
        System.out.println(Arrays.toString(newArr2));

        //fill:填充数组
        System.out.println("---------------fill---------------");
        Arrays.fill(arr, 100);
        System.out.println(Arrays.toString(arr));

        //sort:排序,默认情况下,给基本数据类型进行升序排列,底层使用的是快速排序
        System.out.println("------------sort------------------");
        int[] arr2 = {10, 2, 3, 5, 6, 1, 7, 8, 4, 9};
        Arrays.sort(arr2);
        System.out.println(Arrays.toString(arr2));


    }
}
