package MathDemo;

public class MathDemo1 {
    //abs 获取参数的绝对值
    public static void main(String[] args) {
        System.out.println(Math.abs(-88));
        //bug;
        //以int类型为例,取值范围: -2147483648 ~ 2147483647
        System.out.println(Math.abs(-2147483648));
        System.out.println(Math.ceil(12.34));
        //获取两个整数的较大值
        System.out.println(Math.max(20, 30));
        //获取两个整数的较小值
        System.out.println(Math.min(20, 30));
        //获取a的b次幂
        System.out.println(Math.pow(2, 3));
        //细节
        //如果第二个参数0~1之间的小数
        System.out.println(Math.pow(4, 0.5));
        System.out.println(Math.pow(2, -2));
        for (int i = 0; i < 10; i++) {
            System.out.println(Math.floor(Math.random()*100)+1);
        }
    }
}
