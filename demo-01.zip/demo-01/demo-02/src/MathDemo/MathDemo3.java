package MathDemo;

public class MathDemo3 {
    public static void main(String[] args) {
        //要求1: 统计一共有多少个水仙花数.

        //水仙花数: 100~999
        int count = 0;
        //得到每一个三位数
        for (int i = 100; i <= 999; i++) {
            int ge = i % 10;
            int shi = i / 10 % 10;
            int bai = i / 100 % 10;

            double sum = Math.pow(ge, 3) + Math.pow(shi, 3) + Math.pow(bai, 3);
            if (sum == i){
                count++;
//                System.out.println(i);
            }
        }
        System.out.println(count);
    }
}

