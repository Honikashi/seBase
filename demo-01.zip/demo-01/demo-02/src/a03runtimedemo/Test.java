package a03runtimedemo;

public class Test {
    public static void main(String[] args) {
        new Myjframe();
    }
}
