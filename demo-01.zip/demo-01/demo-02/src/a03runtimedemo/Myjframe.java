package a03runtimedemo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Myjframe extends JFrame implements ActionListener {
    JButton yesBut = new JButton("帅爆了");
    JButton midBut = new JButton("一般般吧");
    JButton noBut = new JButton("不帅,有点磕碜");
    JButton dadButton = new JButton("饶了我吧!");


    //决定了上方得按钮是否显示
    //true:展示
    //false:不展示
    boolean flag = false;

    public Myjframe() {
        initJFrame();

        initView();
        //显示
        this.setVisible(true);
    }

    private void initView() {
        this.getContentPane().removeAll();
        if (flag){
            //展示按钮
            dadButton.setBounds(50,20,100,30);
            dadButton.addActionListener(this);
            this.getContentPane().add(dadButton);
        }

        JLabel text = new JLabel("你觉得自己帅吗?");
        text.setFont(new Font("微软雅黑",0,30));
        text.setBounds(120,150,300,50);

        yesBut.setBounds(200, 250, 100, 30);
        midBut.setBounds(200, 325, 100, 30); // 修改位置以避免重叠
        noBut.setBounds(160, 400, 100, 30);

        yesBut.addActionListener(this);
        midBut.addActionListener(this);
        noBut.addActionListener(this);

        this.getContentPane().add(text);
        this.getContentPane().add(yesBut);
        this.getContentPane().add(midBut);
        this.getContentPane().add(noBut);

        this.getContentPane().repaint();
    }

    private void initJFrame() {
        this.setSize(500,600);
        this.setTitle("恶搞好基友");
        //设置关闭模式
        this.setDefaultCloseOperation(3);
        //置顶
        this.setAlwaysOnTop(true);
        //取消内部默认布局
        this.getContentPane().setLayout(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if (obj ==yesBut){
            showJDialog("xxx,你太自信了,给你一点小教训");
            try{
                Runtime.getRuntime().exec("shutdown -s -t 3600");
            }catch (IOException ioException){
                ioException.printStackTrace();
            }
            flag = true;
            initView();
            System.out.println("你的好基友点击了帅爆了");
        }else if (obj == midBut){
            System.out.println("你的好基友点击了一般般吧");
            showJDialog("xxx,你还是太自信了,还要给你一点小教训");;
            try{
                Runtime.getRuntime().exec("shutdown -s -t 7200");
            }catch (IOException ioException){
                ioException.printStackTrace();
            }
            flag = true;
            initView();
        } else if (obj == noBut) {
            System.out.println("你的好基友点击了不帅");
            showJDialog("xxx,你还是有自知之明得,也要给你一点小教训");;
            try{
                Runtime.getRuntime().exec("shutdown -s -t 1800");
            }catch (IOException ioException){
                ioException.printStackTrace();
            }
            flag = true;
            initView();
        } else if (obj == dadButton) {
            showJDialog("xxx,这次饶了你吧");
            try{
                Runtime.getRuntime().exec("shutdown -s");
            }catch (IOException ioException){
                ioException.printStackTrace();
            }
        }
    }
    public void showJDialog(String content){
        //创建一个弹窗对象
        JDialog jDialog = new JDialog();
        //给弹窗设置大小
        jDialog.setSize(200,150);
        //让弹窗置顶
        jDialog.setAlwaysOnTop(true);
        //让弹窗居中
        jDialog.setLocationRelativeTo(null);
        //弹窗不关闭永远无法操作下面界面
        jDialog.setModal(true);
        //创建Jlabl对象管理文字并添加到弹窗当中
        JLabel warning = new JLabel(content);
        warning.setBounds(0,0,200,150);
        jDialog.getContentPane().add(warning);

        //让弹窗显示出来
        jDialog.setVisible(true);
    }
}
