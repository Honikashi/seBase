package search;

import java.util.ArrayList;

public class A02_BasicSearchDemo2 {
    public static void main(String[] args) {
        //{131,127,147,81,103,23,7,79}
        int[] arr = {131,127,147,81,103,23,7,79,81};
        ArrayList list = BasicSearch(arr, 81);
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));

        }
    }
    public static ArrayList BasicSearch(int[] arr,int number){
        ArrayList<Integer> arrayList= new ArrayList<>();

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == number){
                arrayList.add(i);
            }
        }
        return arrayList;
    }

}
