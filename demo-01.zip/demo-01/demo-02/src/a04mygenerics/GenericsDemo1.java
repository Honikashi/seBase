package a04mygenerics;

public class GenericsDemo1 {
    public static void main(String[] args) {
        //没有泛型的时候,集合如何存储数据
    }
}
