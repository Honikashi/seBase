package a03integerDemo1;

import java.util.Scanner;

public class A05_IntegerDemo5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String line = sc.nextLine();
        System.out.println(line);
    }
}
