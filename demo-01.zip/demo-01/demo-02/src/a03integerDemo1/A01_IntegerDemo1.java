package a03integerDemo1;

public class A01_IntegerDemo1 {
    public static void main(String[] args) {

        //1.利用构造方法获取Integer的对象(JDK5以前的方式)
        Integer i1 = new Integer(1);
        Integer i2 = new Integer("1");
        System.out.println(i1);
        System.out.println(i2);

        //2.利用静态方法获取Integer的对象
        Integer i3 = Integer.valueOf(123);
        Integer i4 = Integer.valueOf("123");
        Integer i5 = Integer.valueOf("123", 8);

        System.out.println(i3);
        System.out.println(i4);
        System.out.println(i5);//83

        //3.这两种方式获取对象的区别(掌握)

    }
}
