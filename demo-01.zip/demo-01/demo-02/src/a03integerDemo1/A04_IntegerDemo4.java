package a03integerDemo1;

public class A04_IntegerDemo4 {
    public static void main(String[] args) {
        //1.把整数转成二进制,八进制,十六进制
        String str1 = Integer.toBinaryString(100);
        System.out.println(str1);
        //2.转八
        String str2 = Integer.toOctalString(100);
        //3.转十六
        String str3 = Integer.toHexString(100);

        //4.将字符串类型的整数转成int类型的整数

        int i = Integer.parseInt("123");
        System.out.println(i+1);
        //细节1:
        //括号内只能是数字
        //细节:
        //八种包装类当中,除了Character都有对应的parseXxx的方法
        String str = "true";
        boolean b = Boolean.parseBoolean(str);
        System.out.println(b);
    }
}
