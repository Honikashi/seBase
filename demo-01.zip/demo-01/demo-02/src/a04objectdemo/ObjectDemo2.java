package a04objectdemo;

public class ObjectDemo2 {

    // public boolean equals(objec obj)    比较两个对象是否相等
    public static void main(String[] args) {
        Student s1 = new Student("zhangsan",23);
        Student s2 = new Student("zhangsan",23);

        boolean result = s1.equals(s2);
        System.out.println(result);//true


    }

}
