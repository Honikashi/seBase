package a02SystemDemo;

public class SystemDemo1 {
    public static void main(String[] args) {
        /*
        public static void exit(int status) 终止当前运行的java虚拟机
        public static long currentTimeMillis() 返回当前系统的时间毫秒值的形式
        public static long arraycopy(数据源数组,起始索引,目的地数组,起始索引,拷贝个数) 数组拷贝



        */
        //方法的形参
        //状态码
        //0:表示当前的虚拟机是正常运行
        //非0:表示当前虚拟机是异常停止
//        System.exit(0);
//        System.out.println("看看我执行了吗");
//        long l = System.currentTimeMillis();
//        System.out.println(l);

        //课堂练习:

        int[] arr1 = {1,2,3,4,5,6,7,8,9,10};
        int[] arr2 = new int[arr1.length];
        System.arraycopy(arr1,6,arr2,2,3);
        for (int i = 0; i < arr2.length; i++) {
            System.out.print(arr2[i]+" ");
        }
    }
}
